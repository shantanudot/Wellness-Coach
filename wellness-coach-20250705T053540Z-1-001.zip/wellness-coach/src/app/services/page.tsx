const page = () => {
  return <></>;
};

export default page;
