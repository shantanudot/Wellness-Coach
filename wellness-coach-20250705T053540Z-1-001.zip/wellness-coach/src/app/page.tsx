import HomeHero, { Calendar20 } from "@/components/HeroSection/HomeHero";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Home | Outdoor Adventure",
  description: "Home page of Outdoor Adventure",
};

const page = () => {
  return (
    <>
      <HomeHero />

      <Calendar20 />
    </>
  );
};

export default page;
