import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";

const Footer = () => {
  return (
    <section className="h-[300] bg-green-100">
      <div className="flex flex-col items-center justify-center gap-4 pt-12 pb-9">
        <h6 className="text-6xl">Lumora</h6>
        <p>Get news about our latest sale dates</p>
      </div>
      <Separator className="p-[1px]" />
      <div className="flex items-center justify-between px-20">
        <div className="">Copyright © 2025 Lumora</div>
        <div className="flex gap-4 pt-4">
          <Avatar className="">
            <AvatarImage
              src="https://play-lh.googleusercontent.com/KRQ7JB6faUWiSt-1SHfcMVOipDMjU5scSPhLttsc9Mc6c5nMiAEKZuIn0_slAz3o0Dc"
              className=""
            />

            <AvatarFallback>CN</AvatarFallback>
          </Avatar>
          <Avatar className="">
            <AvatarImage src="https://miro.medium.com/v2/resize:fit:1400/1*NNI7aPLtSaLo6jb4KGEFDA.jpeg" />

            <AvatarFallback></AvatarFallback>
          </Avatar>
          <Avatar className="">
            <AvatarImage src="https://i.pcmag.com/imagery/reviews/068BjcjwBw0snwHIq0KNo5m-15..v1602794215.png" />

            <AvatarFallback></AvatarFallback>
          </Avatar>
          <Avatar className="">
            <AvatarImage src="https://static.thearcweb.com/images/PROD/PROD-aa944068-e222-41c1-83a1-4cf50c14444e.png" />

            <AvatarFallback></AvatarFallback>
          </Avatar>
        </div>
      </div>
    </section>
  );
};

export default Footer;
