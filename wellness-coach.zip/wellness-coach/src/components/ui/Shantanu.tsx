import { AuroraText } from "../magicui/aurora-text";
import { SparklesText } from "../magicui/sparkles-text";

const Shantanu = () => {
  return (
    <section className="flex h-[630] flex-col items-center justify-center gap-4 bg-black/50 text-5xl font-bold">
      <SparklesText className="text-gray-800">
        Shantanu's gonna finish it super quick!
      </SparklesText>
      <AuroraText>"Give it a moment, "</AuroraText>
    </section>
  );
};

export default Shantanu;
