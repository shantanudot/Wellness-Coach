import Image from "next/image";
import { ShimmerButton } from "../magicui/shimmer-button";

const ChangeLife = () => {
  return (
    <section className="px-24 py-28">
      <div className="grid grid-cols-2 items-center">
        <div className="">
          <Image
            src="/home/Book-an-Appointment-Sec-IMG.jpg"
            alt=""
            height={328}
            width={500}
            className="w-fit rounded-sm"
          />
        </div>
        <div className="flex flex-col gap-12 pl-32">
          <div className="text-5xl leading-tight">
            Change your life through professional health coaching
          </div>
          <div className="">
            I help clients transform their health through personalized nutrition
            and sustainable habits. I’ve guided over 100 clients to better
            well-being by focusing on small, manageable changes that lead to
            lasting results.
          </div>
          <div className="">
            <ShimmerButton>Book An Appoinment</ShimmerButton>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ChangeLife;
