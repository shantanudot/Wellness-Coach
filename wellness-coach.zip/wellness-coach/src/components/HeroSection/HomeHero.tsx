"use client";

import * as React from "react";

import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Card, CardContent, CardFooter } from "@/components/ui/card";

export function Calendar20() {
  const [date, setDate] = React.useState<Date | undefined>(
    new Date(2025, 5, 12),
  );
  const [selectedTime, setSelectedTime] = React.useState<string | null>(
    "10:00",
  );
  const timeSlots = Array.from({ length: 37 }, (_, i) => {
    const totalMinutes = i * 15;
    const hour = Math.floor(totalMinutes / 60) + 9;
    const minute = totalMinutes % 60;
    return `${hour.toString().padStart(2, "0")}:${minute.toString().padStart(2, "0")}`;
  });

  const bookedDates = Array.from(
    { length: 3 },
    (_, i) => new Date(2025, 5, 17 + i),
  );

  return (
    <Card className="grid grid-cols-2 items-center rounded-xl">
      <CardContent className="relative p-0 md:pr-48">
        <div className="p-2">
          <Calendar
            mode="single"
            selected={date}
            onSelect={setDate}
            defaultMonth={date}
            disabled={bookedDates}
            showOutsideDays={false}
            modifiers={{
              booked: bookedDates,
            }}
            modifiersClassNames={{
              booked: "[&>button]:line-through opacity-100",
            }}
            className="bg-transparent p-0 [--cell-size:--spacing(10)] md:[--cell-size:--spacing(12)]"
            formatters={{
              formatWeekdayName: (date) => {
                return date.toLocaleString("en-US", { weekday: "short" });
              },
            }}
          />
        </div>

        <div className="no-scrollbar inset-y-0 right-0 flex max-h-72 w-full scroll-pb-6 flex-col gap-4 overflow-y-auto border-t p-6 md:absolute md:max-h-none md:w-48 md:border-t-0 md:border-l">
          <div className="grid gap-2">
            {timeSlots.map((time) => (
              <Button
                key={time}
                variant={selectedTime === time ? "default" : "outline"}
                onClick={() => setSelectedTime(time)}
                className="w-full shadow-none">
                {time}
              </Button>
            ))}
          </div>
        </div>

        <CardFooter className="flex flex-col gap-4 border-t px-6 py-5 md:flex-row">
          <div className="text-sm">
            {date && selectedTime ? (
              <>
                Your meeting is booked for{" "}
                <span className="font-medium">
                  {" "}
                  {date?.toLocaleDateString("en-US", {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                  })}{" "}
                </span>
                at <span className="font-medium">{selectedTime}</span>.
              </>
            ) : (
              <>Select a date and time for your meeting.</>
            )}
          </div>

          <Button
            disabled={!date || !selectedTime}
            className="w-full cursor-pointer md:ml-auto md:w-auto"
            variant="secondary">
            Continue
          </Button>
        </CardFooter>
      </CardContent>
      <div className="flex flex-col justify-center gap-8 p-10">
        <div className="text-xl">
          <i>Book an Appointment</i>
        </div>
        <div className="text-6xl">
          Wellness coaching <br /> with Lumora
        </div>
        <div className="">
          Achieve balance and well-being with personalized coaching tailored to
          your needs. Lumora guides you through sustainable lifestyle changes to
          help you reach your health and wellness goals.
        </div>
      </div>
    </Card>
  );
}

const HomeHero = () => {
  return (
    <>
      <section className="mt-20 bg-[url(/home/cover.webp)] bg-cover bg-no-repeat text-white">
        <div className="grid place-items-start py-48 pl-16">
          <div className="space-y-6 text-center">
            <div className="text-3xl tracking-wide">
              Calorie control, balanced nutrition
            </div>

            <div className="text-7xl tracking-wide">
              Start living your <br /> healthiest life
            </div>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 py-10"></section>
    </>
  );
};

export default HomeHero;
