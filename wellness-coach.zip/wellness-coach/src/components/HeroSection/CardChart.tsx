import { Card, CardContent, CardFooter } from "@/components/ui/card";
import Image from "next/image";
import { ShimmerButton } from "../magicui/shimmer-button";

const CardChart = () => {
  return (
    <section className="flex flex-col items-center justify-center gap-3 bg-green-100 py-24">
      <div className="flex flex-col items-center justify-center gap-3 bg-green-100 pb-20">
        <div className="text-xl font-bold">Coaching Services</div>
        <div className="text-5xl">Create the life you want to live</div>
      </div>

      <div className="flex flex-col gap-20">
        <div className="flex gap-6 px-28">
          <div className="grid">
            <Card>
              <CardContent className="flex">
                <Image
                  src="/home/person.jpg"
                  alt=""
                  height={328}
                  width={500}
                  className="w-fit"
                />
              </CardContent>
              <CardFooter className="flex flex-col items-start gap-4 px-7">
                <div className="font-bold">Personalized nutrition plans</div>
                <div className="">
                  Create customized meal plans tailored to your individual
                  health goals, needs lifestyle preferences to help you achieve
                  optimal wellness. <b>start from: $500</b>
                </div>
                <div className="">
                  <ShimmerButton>Book An Appoinment</ShimmerButton>
                </div>
              </CardFooter>
            </Card>
          </div>

          <div className="grid">
            <Card>
              <CardContent className="flex">
                <Image
                  src="/home/Weight-management-counseling.jpg"
                  alt=""
                  height={328}
                  width={500}
                  className="w-fit"
                />
              </CardContent>
              <CardFooter className="flex flex-col items-start gap-4 px-7">
                <div className="font-bold">Weight management counseling</div>
                <div className="">
                  Through tailored nutrition plans, behavioral coaching, and
                  fitness advice, we focus on sustainable results your overall
                  well-being.
                  <b>start from: $1,000</b>
                </div>
                <div className="">
                  <ShimmerButton>Book An Appoinment</ShimmerButton>
                </div>
              </CardFooter>
            </Card>
          </div>
        </div>
        <div className="flex gap-6 px-28">
          <div className="grid">
            <Card>
              <CardContent className="flex">
                <Image
                  src="/home/Health-and-wellness-coaching.jpg"
                  alt=""
                  height={328}
                  width={500}
                  className="w-fit"
                />
              </CardContent>
              <CardFooter className="flex flex-col items-start gap-4 px-7">
                <div className="font-bold">Health and wellness coaching</div>
                <div className="">
                  Create customized meal plans tailored to your individual
                  health goals, needs lifestyle preferences to help you achieve
                  optimal wellness. <b>start from: $500</b>
                </div>
                <div className="">
                  <ShimmerButton>Book An Appoinment</ShimmerButton>
                </div>
              </CardFooter>
            </Card>
          </div>

          <div className="grid">
            <Card>
              <CardContent className="flex">
                <Image
                  src="/home/Expand-your-spiritual-knowledge.jpg"
                  alt=""
                  height={328}
                  width={500}
                  className="w-fit"
                />
              </CardContent>
              <CardFooter className="flex flex-col items-start gap-4 px-7">
                <div className="font-bold">
                  Expand your spiritual knowledge{" "}
                </div>
                <div className="">
                  Through tailored nutrition plans, behavioral coaching, and
                  fitness advice, we focus on sustainable results your overall
                  well-being.
                  <b>start from: $1,500</b>
                </div>
                <div className="">
                  <ShimmerButton>Book An Appoinment</ShimmerButton>
                </div>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CardChart;
