import Shantanu from "@/components/ui/Shantanu";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Services | wellness Coach",
  description: "Services page of wellness Coach",
};

const page = () => {
  return (
    <>
      <Shantanu />
    </>
  );
};

export default page;
