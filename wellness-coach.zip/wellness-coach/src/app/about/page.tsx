import Shantanu from "@/components/ui/Shantanu";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "About | wellness Coach",
  description: "About page of wellness Coach",
};

const page = () => {
  return (
    <>
      <Shantanu />
    </>
  );
};

export default page;
