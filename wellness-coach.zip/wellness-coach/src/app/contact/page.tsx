import Shantanu from "@/components/ui/Shantanu";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact | wellness Coach",
  description: "Contact page of wellness Coach",
};

const page = () => {
  return (
    <>
      <Shantanu />
    </>
  );
};

export default page;
