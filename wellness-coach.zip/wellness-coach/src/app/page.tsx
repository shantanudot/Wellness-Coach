import CardChart from "@/components/HeroSection/CardChart";
import ChangeLife from "@/components/HeroSection/ChangeLife";
import HomeHero, { Calendar20 } from "@/components/HeroSection/HomeHero";
import Footer from "@/components/ui/Footer";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Home | wellness Coach",
  description: "Home page of wellness Coach",
};

const page = () => {
  return (
    <>
      <HomeHero />
      <Calendar20 />
      <CardChart />
      <ChangeLife />
      <Footer />
    </>
  );
};

export default page;
